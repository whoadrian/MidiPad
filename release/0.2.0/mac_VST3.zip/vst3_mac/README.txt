Welcome to MidiPad!


Install Instructions:

Copy MidiPad.vst3 at /Users/<username>/Library/Audio/Plug-Ins/VST3/
...or anywhere where your other VST3 plugins are :)


MidiPad Instructions:

Hover your mouse over MidiPad and it will send Midi CC messages for the X and Y axes.
You can select the CC Channel, as well as the Midi Channel per axis.
Clicking on the Pad area will Lock/Unlock the cursor.


Notes:

Ableton has a weird relationship with MIDI-only plugins. 
A nice way of working with MidiPad in Ableton is to add it to its own MIDI track. 
In your other tracks with synths, select as MIDI Input, MidiPad from its respective track.
